require 'spec_helper'

describe MoviesController do
 describe 'similar' do
  before :each do
   @fake_movies=[mock('movie'),mock('movie')]
  end

  it 'should call the model method that search similar movies' do
    m= mock('movie',:director=>'Director')
    Movie.should_receive(:find_by_id).with("1").and_return(m)
    Movie.should_receive(:find_all_by_director)
         .with("Director")
         .and_return(@fake_movies)
    get :similar,:id=>"1"
  end
 # it 'should render home page when movie has no director' do
# end
 end 
end
