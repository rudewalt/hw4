require 'spec_helper'

describe MoviesController do
 fixtures:movies
 describe 'similar' do
  before :each do
   @fake_movies=[mock('movie'),mock('movie')]
  end
  it 'should call the model method that search similar movies' do
    m= mock('movie',:director=>'Director')
    Movie.should_receive(:find_by_id).with("1").and_return(m)
    Movie.should_receive(:find_all_by_director)
         .with("Director")
         .and_return(@fake_movies)
    get :similar,:id=>"1"
  end
  it 'should render home page when movie has no director' do
    get :similar,:id=>1
    response.should redirect_to movies_path
  end
 end

 describe 'general'do
  it 'should sort movies by date'do
    get :index,{:sort=>'release_date'}
    assigns(:date_header).should=='hilite'
  end
  it 'should sort by title'do
    get :index,{:sort=>'title'}
    assigns(:title_header).should=='hilite'
  end
  it 'should show more information about movie' do
    m=mock(:movie,:title=>'Movie title')
    Movie.should_receive(:find).with("1").and_return(m)
    get :index,:id=>"1"
  end
 end

 describe 'create'do
  it 'should create new movie' do
   release_date=1.years.ago
   post :create,{:movie=>{:title=>'Movie123123',:release_date=>release_date}}
   Movie.find_by_title('Movie123123').release_date.to_s.should==release_date.to_s
   response.should redirect_to movies_path
  end
 end

 describe 'remove'do
  it 'should remove movie from database'do
    delete :destroy,:id=>1
    Movie.find_by_id(1).should==nil
  end
 end

 describe 'update' do
  it 'should show edit form'do
    get :edit,:id=>1
    response.should render_template(:edit)
  end

  it 'should update info'do
   put :update,{:id=>1,:movie=>{:title=>'Movie'}}
   Movie.find_by_id(1).title.should=='Movie'
  end
 end
end
