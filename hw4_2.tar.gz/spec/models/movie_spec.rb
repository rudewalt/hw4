require 'spec_helper'

describe Movie do
   it 'should search similar movies'do
    assert true
   end
end
